
var gameLoop = new GameLoop();

var gameTitle = new Title( gameLoop );

var stateDefinitions = new StateDefinitions( gameLoop, gameTitle );
